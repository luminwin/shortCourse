#' plot error
#'
#' Plot error rate for a rfsrc class object.
#'
#' @param o rfsrc object 
#' @param standardize standardize values
#' @param trim used for trimming vimp for multivariate plots
#' @param cex for setting size for some of the plots
#' @param xlab label for x-axis
#' @param ylab label for y-axis
#' @param title display title?
#' 
#' @export

plot.vimp <- function(x, standardize = TRUE, trim = 0, cex = 1,
        xlab = "Importance", ylab = "", title = TRUE, show.plots = TRUE) {

  ## coherence check
  if (sum(inherits(x, c("rfsrc", "grow"), TRUE) == c(1, 2)) != 2) {
    stop("This function only works for objects of class `(rfsrc, grow)'")
  }

  ## check that vimp is available
  if (x$family != "surv-CR") {
    if (x$family != "class") {
      vmp <- get.mv.vimp(x, TRUE)
    }
    else {
      vmp <- x$importance
    }
    if (is.null(vmp)) {
      cat("no importance found: calculating it now ...\n")
      if (x$family != "class") {
        vmp <- get.mv.vimp(vimp(x, importance="permute", block.size=1), TRUE)
      }
      else {
        vmp <- vimp(x, importance="permute")$importance
      }
    }
  }
            
  ## family specific processing
  if (x$family == "regr" | x$family == "surv") {
    vmp <- data.frame(variable = rownames(vmp), importance = vmp[, 1])
    g <- ggplot(vmp, aes(x = reorder(variable, importance), y = importance)) +
      geom_bar(stat = "identity", fill = "#F8766D") +
      theme_minimal() + coord_flip() + labs(x = ylab, y = xlab) 
    if (title) {
      g <- g + labs(title = "Variable Importance")
    }
  }
  else if (x$family == "class") {
    J <- length(sort(unique(x$yvar)))
    g <- lapply(1:ncol(vmp), function(j) {
      df <- data.frame(variable = rownames(vmp), importance = vmp[, j])
      gg <- ggplot(df, aes(x = reorder(variable, importance), y = importance)) +
        geom_bar(stat = "identity", fill = "#F8766D") + coord_flip() + theme_minimal() +
        labs(x = ylab, y = xlab)
      if (title) {
        gg <- gg + labs(title = paste("Variable Importance:", colnames(vmp)[j])) 
      }
      if (J < 5) {
        theme.vimp(gg)
      }
      else {
        theme.vimp(gg, .6)
      }
    })
    if (J < 5) {
      g <- wrap_plots(g, ncol = length(g))
    }
    else {
      g <- wrap_plots(g, ncol = min(length(g), 4))
    }
  }
  else if (x$family == "surv-CR") {
    events <- x$event.info$event.type
    nevents <- length(events)
    g <- lapply(1:nevents, function(j) {
      cat("fitting event specific forest...", j, "\n")
      cause <- rep(0, nevents)
      cause[j] <- 1
      imp <- rfsrc(formula = new_formula(f_lhs(formula(x$call)), quote(.)),
                  data = data.frame(x$yvar, x$xvar),
                  ntree = x$ntree,
                  splitrule = "logrank",
                  nodesize = x$nodesize,
                  importance = "permute",
                  cause = cause)$importance
      df <- data.frame(variable = rownames(imp), importance = imp[, j])
      gg <- ggplot(df, aes(x = reorder(variable, importance), y = importance)) +
              geom_bar(stat = "identity", fill = "#F8766D") + coord_flip() + theme_minimal() +
              labs(x = ylab, y = xlab)
      if (title) {
        gg <- gg + labs(title = paste("Variable Importance: Event", events[j]))
      }
      theme.vimp(gg, 1, .8)
    })
    if (nevents < 5) {
      g <- wrap_plots(g, ncol = length(g))
    }
    else {
      g <- wrap_plots(g, ncol = min(length(g), 4))
    }
  }
  else if (x$family == "regr+" | x$family == "class+" | x$family == "mix+") {
    outcomes <- x$yvar.names
    q <- quantile(vmp, trim)
    pt <- apply(vmp, 1, function(x){all(abs(x) >= q)})
    vmp <- vmp[pt,, drop = FALSE]
    if (nrow(vmp) == 0) {
      stop("trim is set too high, no variables meet that cutoff")
    }
    g <- lapply(1:length(outcomes), function(j) {
      df <- data.frame(variable = rownames(vmp), importance = vmp[, j])
      gg <- ggplot(df, aes(x = reorder(variable, importance), y = importance)) +
        geom_bar(stat = "identity", fill = "#F8766D") + coord_flip() + theme_minimal() 
      if (title) {
        gg <- gg + labs(title = outcomes[j])
      }
      theme.vimp(gg, .6 * cex)
    })
    g <- wrap_plots(g, ncol = min(length(g), 4))
  }
  else {
    stop("the supplied example is not a supported family")
  }

  ## return the plot
  if (show.plots) {
    g
  }
  else {
    invisible(g)
  }

  
  
}

